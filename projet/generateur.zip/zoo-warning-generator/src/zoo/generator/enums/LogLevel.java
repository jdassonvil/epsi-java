package zoo.generator.enums;

public enum LogLevel {
	
	ERROR, IMPORTANT, NORMAL;

}
