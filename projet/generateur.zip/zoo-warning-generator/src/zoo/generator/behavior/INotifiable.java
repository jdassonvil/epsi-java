package zoo.generator.behavior;

import zoo.generator.model.Trame;

public interface INotifiable {

	public void notify(Trame t);
}
