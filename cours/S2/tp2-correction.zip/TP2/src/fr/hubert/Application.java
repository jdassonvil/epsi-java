package fr.hubert;
import java.util.ArrayList;
import java.util.List;

import fr.hubert.exception.AuthentificationException;
import fr.hubert.exception.TaxiNotFoundException;
import fr.hubert.model.Admin;
import fr.hubert.model.Chauffeur;
import fr.hubert.model.Client;
import fr.hubert.model.Helicoptere;
import fr.hubert.model.Moto;
import fr.hubert.model.Utilisateur;
import fr.hubert.model.Voiture;

public class Application {
	
	private static List<Utilisateur> utilisateurs = new ArrayList<>();
	
	private static Utilisateur trouverUtilisateur(String username){
		for(Utilisateur u : utilisateurs){
			if(u.getUsername().equals(username)){
				return u;
			}
		}
		return null;
	}
	
	public static Client creerCompteClient(String nom, String prenom, String adresse, String email, String password) throws Exception{
		
		if(trouverUtilisateur(email) != null){
			throw new Exception("ce compte existe d�j�");

		}
		
		Client c = new Client(nom, prenom, adresse, email, password);
		utilisateurs.add(c);
		return c;
	}
	
	public static Chauffeur creerCompteChauffeur(String nom, String prenom, String adresse, String email, String password, short license) throws Exception{
		
		if(trouverUtilisateur(email) != null){
			throw new Exception("ce compte existe d�j�");

		}
		
		Chauffeur c = new Chauffeur(nom, prenom, adresse, email, password, license);
		utilisateurs.add(c);
		return c;
	}
	
	public static Admin creerCompteAdmin(String email, String password) throws Exception{
		
		if(trouverUtilisateur(email) != null){
			throw new Exception("ce compte existe d�j�");

		}
		
		Admin c = new Admin(email, password);
		utilisateurs.add(c);
		return c;
	}
	
	public static Utilisateur authentifie(String username, String password) throws AuthentificationException{
		Utilisateur u = trouverUtilisateur(username);
		
		if(u == null){
			throw new AuthentificationException();
		}
		
		if(!u.checkPassword(password)){
			throw new AuthentificationException();
		}
		
		return u;
	}
	
	public static List<Chauffeur> trouverTaxi(int position) throws TaxiNotFoundException{
		
		List<Chauffeur> chauffeursDisponibles = new ArrayList<>();
		
		for(Utilisateur u: utilisateurs){
			if(u instanceof Chauffeur){
				Chauffeur c = (Chauffeur)u;
				
				if(c.getPosition() ==  position && c.estDisponible() && c.getVehicule() != null){
					chauffeursDisponibles.add(c);
				}
			}
		}
		
		if(chauffeursDisponibles.size() == 0 ){
			throw new TaxiNotFoundException();
		}
		
		return chauffeursDisponibles;
	}
	
	public static int nbUtilisateurs(){
		return utilisateurs.size();
	}
	
	public static int nbMoto(){
		int nbMoto = 0;
		for(Utilisateur u : utilisateurs){
			if(u instanceof Chauffeur && ((Chauffeur) u).getVehicule() instanceof Moto){
				nbMoto++;
			}
		}
		
		return nbMoto;
	}
	
	public static int nbHelico(){
		int nbHelico = 0;
		for(Utilisateur u : utilisateurs){
			if(u instanceof Chauffeur && ((Chauffeur) u).getVehicule() instanceof Helicoptere){
				nbHelico++;
			}
		}
		
		return nbHelico;
	}
	
	public static int nbVoiture(){
		int nbVoiture = 0;
		for(Utilisateur u : utilisateurs){
			if(u instanceof Chauffeur && ((Chauffeur) u).getVehicule() instanceof Voiture){
				nbVoiture++;
			}
		}
		
		return nbVoiture;
	}

}
