package fr.hubert.exception;

public class TaxiNotFoundException extends Exception {

	private static final long serialVersionUID = -5466234124784957534L;


}
