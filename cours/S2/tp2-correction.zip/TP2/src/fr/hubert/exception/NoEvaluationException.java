package fr.hubert.exception;

public class NoEvaluationException extends Exception {

	private static final long serialVersionUID = -679298321557423912L;

}
