package fr.hubert.model;

public abstract class Vehicule {
	
	protected String marque;
	protected String modele;
	protected short capacite;
	
	public Vehicule(String marque, String modele, short capacite) {
		this.marque = marque;
		this.modele = modele;
		this.capacite = capacite;
	}
	
	public String getMarque() {
		return marque;
	}
	public void setMarque(String marque) {
		this.marque = marque;
	}
	public String getModele() {
		return modele;
	}
	public void setModele(String modele) {
		this.modele = modele;
	}
	public short getCapacite() {
		return capacite;
	}
	public void setCapacite(short capacite) {
		this.capacite = capacite;
	}
	
	public abstract float getTarif();
	
	public abstract String getNomVehicule();
	
	public abstract String getDescription();

}
