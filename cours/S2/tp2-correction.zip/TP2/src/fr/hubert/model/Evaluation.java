package fr.hubert.model;

public class Evaluation {
	
	private String commentaire;
	private short note;
	
	public Evaluation(String commentaire, short note) {
		this.commentaire = commentaire;
		this.note = note;
	}

	public String getCommentaire() {
		return commentaire;
	}

	public short getNote() {
		return note;
	}

}
