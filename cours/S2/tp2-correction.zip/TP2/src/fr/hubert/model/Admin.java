package fr.hubert.model;

public class Admin extends Utilisateur {

	public Admin(String username, String password){
		super(username, password);
	}
}
