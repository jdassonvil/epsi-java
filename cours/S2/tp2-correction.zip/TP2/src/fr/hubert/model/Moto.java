package fr.hubert.model;

public class Moto extends Vehicule {
	
	private static short CAPACITE_MOTO = 1;
	private String immatriculation;
	
	// Tarif en � au km
	private static float TARIF = 3f;
	
	private static String TYPE = "MOTO";

	public Moto(String marque, String modele, String immatriculation) {
		super(marque, modele, CAPACITE_MOTO);
		this.immatriculation = immatriculation;
	}

	@Override
	public float getTarif() {
		return TARIF;
	}
	
	public String getImmatriculation() {
		return immatriculation;
	}
	
	@Override
	public String getNomVehicule() {
		return TYPE;
	}
	
	@Override
	public String getDescription() {
		return this.getMarque() + " " + this.getModele() + " pour " + this.capacite + " personne(s)";
	}
}
