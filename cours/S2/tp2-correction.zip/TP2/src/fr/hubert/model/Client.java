package fr.hubert.model;

import java.util.LinkedList;
import java.util.List;

import fr.hubert.exception.NoEvaluationException;
import fr.hubert.interfaces.IEvaluable;

public class Client extends Utilisateur implements IEvaluable{
	
	private String nom;
	private String prenom;
	private String adresse;
	private String email;
	
	private static int compteur = 0;
	
	private List<Evaluation> evaluations = new LinkedList<Evaluation>();
	
	public Client(String nom, String prenom, String adresse, String email, String password) {
		super(email, password);

		this.nom = nom;
		this.prenom = prenom;
		this.adresse = adresse;
		this.email = email;
		compteur++;
	}
	
	public static int getNbClient(){
		return compteur;
	}
	
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public String getAdresse() {
		return adresse;
	}
	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	@Override
	public String toString() {
		return "Client [nom=" + nom + ", prenom=" + prenom + ", adresse="
				+ adresse + ", email=" + email + "]";
	}
	
	@Override
	public void setEvaluation(short note) {
		this.evaluations.add(new Evaluation("", note));
		
	}

	@Override
	public int getEvaluationMoyenne() throws NoEvaluationException {
		
		if(evaluations.size() == 0){
			throw new NoEvaluationException();
		}
		
		int somme = 0;
		for(Evaluation eval: evaluations){
			somme += eval.getNote();
		}
		
		return somme/evaluations.size();
	}

	@Override
	public List<Evaluation> getEvaluations() {
		return evaluations;
	}

}
