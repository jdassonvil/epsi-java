package fr.hubert.model;

public class Voiture extends Vehicule{
	
	private String immatriculation;
	
	// Tarif en � au km
	private static float TARIF = 1.5f;
	
	private static String TYPE = "VOITURE";
	
	public Voiture(String marque, String modele, short capacite,
			String immatriculation) {
		super(marque, modele, capacite);
		this.immatriculation = immatriculation;
	}

	public String getImmatriculation() {
		return immatriculation;
	}
	
	@Override
	public float getTarif() {
		return TARIF;
	}
	
	@Override
	public String getNomVehicule() {
		return TYPE;
	}
	
	@Override
	public String getDescription() {
		return this.getMarque() + " " + this.getModele() + " pour " + this.capacite + " personne(s)";
	}

}
