package fr.hubert.model;

public class Helicoptere extends Vehicule{
	
	// Tarif en � au km
	private static float TARIF = 10f;
	
	private static String TYPE = "Helico";

	public Helicoptere(String marque, String modele, short capacite) {
		super(marque, modele, capacite);
	}
	
	@Override
	public float getTarif() {
		return TARIF;
	}

	@Override
	public String getNomVehicule() {
		return TYPE;
	}
	
	@Override
	public String getDescription() {
		return this.getMarque() + " " + this.getModele() + " pour " + this.capacite + " personne(s)";
	}
}
