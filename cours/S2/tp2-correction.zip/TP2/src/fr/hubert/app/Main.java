package fr.hubert.app;

import java.util.Scanner;

import fr.hubert.Application;
import fr.hubert.console.Actions;
import fr.hubert.model.Chauffeur;
import fr.hubert.model.Helicoptere;
import fr.hubert.model.Voiture;

public class Main {

	public static void main(String[] args){

		// Jeu de test
		try{
			// Comptes client
			Application.creerCompteClient("Depardieu", "Gerard", "Quelque part en belgique", "gerard.depardieu@gmail.com",
					"bxfr37");
			
			Application.creerCompteClient("Patrick", "Sebastien", "rue garibaldi", "sebastien.patrick@yahoo.com",
					"bxfr37");
			
			Application.creerCompteClient("test", "test", "test", "test@test.com",
					"test");

			// Comptes chauffeur
			Chauffeur c1 = Application.creerCompteChauffeur("Paul", "DeuxMaisons", "12 avenue de le republique", "pdemaisons@outlook.com", "ptaxi", (short)28984849);
			c1.setPosition(69006);
			c1.setVehicule(new Voiture("Citroen", "C5", (short) 3, "KLK 390 DD"));
			
			Chauffeur c2 = Application.creerCompteChauffeur("Jean", "Mineur", "897 avenue des lilas", "jeanjean@montaxi.fr", "ptaxi", (short)9378943);
			c2.setPosition(69006);
			c2.setVehicule(new Voiture("BMW", "Serie 5", (short) 3, "LDD 224 OL"));
			
			Chauffeur c3 = Application.creerCompteChauffeur("Karim", "Belhanda", "30 route de strasbourg", "karimb@allotaxi.fr", "ptaxi", (short)930903);
			c3.setPosition(69006);
			c3.setVehicule(new Helicoptere("Apache", "FX345", (short) 6));
			
			// Compte admin
			Application.creerCompteAdmin("admin@epsi.fr", "admin");
			
		}catch(Exception e){
			e.printStackTrace();
		}

		// Lancement de l'application
		System.out.println("Application de test de l'application Hubert");

		Scanner sc = new Scanner(System.in);

		Actions.showMenu(sc);

		sc.close();
		System.out.println("bye bye");

	}

}
