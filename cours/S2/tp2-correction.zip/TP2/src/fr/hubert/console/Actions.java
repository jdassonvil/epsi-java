package fr.hubert.console;

import java.util.List;
import java.util.Scanner;

import fr.hubert.Application;
import fr.hubert.exception.AuthentificationException;
import fr.hubert.exception.TaxiNotFoundException;
import fr.hubert.model.Admin;
import fr.hubert.model.Chauffeur;
import fr.hubert.model.Client;
import fr.hubert.model.Utilisateur;

public class Actions {
	
	public static void showMenu(Scanner sc){
		
		Utilisateur utilisateur = null;
		boolean exit = false;
		
		while(exit == false){
			try{			
			if(utilisateur != null){
				
				if(utilisateur instanceof Client){
					exit = showActionsClient(sc);
				}else if(utilisateur instanceof Chauffeur){
					exit = showActionsChauffeur(sc);
				}else if(utilisateur instanceof Admin){
					exit = showActionsAdmin(sc);
				}

			}else{
				showActions();
				int action = Integer.parseInt(sc.nextLine());
				
				switch(action){
				case 0:
					exit = true;
					break;
				case 1:
					createNewAccount(sc);
					break;
				case 2:
					utilisateur = login(sc);
					break;
				}
			}
			}catch(NumberFormatException e){
				System.err.println("Option saisie invalide");
			}
		}

	}
	
	public static void rechercherTaxi(Scanner sc){
		System.out.println("Dans quelle commune souhaitez vous trouver un taxi ? ");
		String text = sc.nextLine();
		
		try{
			int cp = Integer.parseInt(text);
			List<Chauffeur> chauffeursDisponnibles = Application.trouverTaxi(cp);
			
			System.out.println("Chauffeurs disponibles: ");

			for(Chauffeur c : chauffeursDisponnibles){
				System.out.println("[" + c.getVehicule().getNomVehicule() + "]" + c.getNom() + " " + c.getPrenom() + " - " + c.getVehicule().getDescription() );
			}		
			
		}catch(NumberFormatException e){
			System.out.println("Merci de saisir un code postal constitu� de 5 chiffres");
		}catch(TaxiNotFoundException e){
			System.err.println("Aucun chauffeur n'est disponible dans votre commune");
		}
	}
	
	public static Utilisateur login(Scanner sc){
		System.out.println("Saisissez votre email");
		String email = sc.nextLine();
		System.out.println("Saisissez un mot de passe");
		String password = sc.nextLine();
		
		try{
			return Application.authentifie(email, password);
		}catch(AuthentificationException e){
			System.err.println("Login ou mot de passe incorrect");
			return null;
		}
	}
	
	public static void showActions(){
		System.out.println("Que souhaitez vous faire ?");
		System.out.println("1) Creer un compte");
		System.out.println("2) Se connecter");
		System.out.println("0) Quitter l'application");
	}
	
	public static boolean showActionsClient(Scanner sc){
		System.out.println("Que souhaitez vous faire ?");
		System.out.println("1) Recherche un taxi");
		System.out.println("0) Quitter l'application");
		
		int action = Integer.parseInt(sc.nextLine());
		
		switch(action){
		case 0:
			return true;
		case 1:
			rechercherTaxi(sc);
			break;
		}
		
		return false;
	}
	
	public static boolean showActionsChauffeur(Scanner sc){
		System.out.println("Que souhaitez vous faire ?");
		System.out.println("0) Quitter l'application");
		
		return false;
	}
	
	public static boolean showActionsAdmin(Scanner sc){
		System.out.println("Que souhaitez vous faire ?");
		System.out.println("1) Afficher les stats");
		System.out.println("0) Quitter l'application");
		
		int action = Integer.parseInt(sc.nextLine());

		switch(action){
		case 0:
			return true;
		case 1:
			afficherStats();
			break;
		}
		
		return false;
	}
	
	public static void afficherStats(){
		System.out.println("Nombre d'utilisateurs: " + Application.nbUtilisateurs());
		System.out.println("Nombre de moto: " + Application.nbMoto());
		System.out.println("Nombre de voiture: " + Application.nbVoiture());
		System.out.println("Nombre d'helicopter:e " + Application.nbHelico());
	}
	
	public static void createNewAccount(Scanner sc){
		System.out.println("Saisissez votre nom");
		String nom = sc.nextLine();
		System.out.println("Saisissez votre prenom");
		String prenom = sc.nextLine();
		System.out.println("Saisissez votre adresse");
		String adresse = sc.nextLine();
		System.out.println("Saisissez votre email");
		String email = sc.nextLine();
		System.out.println("Saisissez un mot de passe");
		String password = sc.nextLine();
		
		try {
			Application.creerCompteClient(nom, prenom, adresse, email, password);
		} catch (Exception e) {
			System.out.println("Cet email est d�j� utilis�");
		}
	}
	
	

}
