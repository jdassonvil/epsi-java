package fr.hubert.interfaces;

public interface IEvaluateur {

	public void evaluer(IEvaluable element);

}
