package fr.hubert.interfaces;

import java.util.List;

import fr.hubert.exception.NoEvaluationException;
import fr.hubert.model.Evaluation;

public interface IEvaluable {
	
	public void setEvaluation(short note);

	public int getEvaluationMoyenne() throws NoEvaluationException;

	public List<Evaluation> getEvaluations();
}
