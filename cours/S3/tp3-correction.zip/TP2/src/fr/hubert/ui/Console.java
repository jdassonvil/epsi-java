package fr.hubert.ui;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

import fr.hubert.app.TCPClient;
import fr.hubert.enums.VehiculeType;
import fr.hubert.model.Admin;
import fr.hubert.model.Chauffeur;
import fr.hubert.model.Client;
import fr.hubert.model.Stats;
import fr.hubert.model.Utilisateur;

public class Console {

	private static TCPClient tcpClient = new TCPClient();

	public static void showMenu(Scanner sc) {

		Utilisateur utilisateur = null;
		boolean exit = false;

		while (exit == false) {
			try {
				if (utilisateur != null) {
					if (utilisateur instanceof Client) {
						exit = showActionsClient(sc);
					} else if (utilisateur instanceof Chauffeur) {
						exit = showActionsChauffeur(sc, utilisateur);
					} else if (utilisateur instanceof Admin) {
						exit = showActionsAdmin(sc);
					}

				} else {
					showActions();
					int action = Integer.parseInt(sc.nextLine());

					switch (action) {
					case 0:
						exit = true;
						break;
					case 1:
						creerNouveauCompte(sc);
						break;
					case 2:
						utilisateur = login(sc);
						break;
					}
				}
			} catch (NumberFormatException e) {
				System.err.println("Option saisie invalide");
			}
		}

	}

	public static void rechercherTaxi(Scanner sc) {
		System.out.println("Dans quelle commune souhaitez vous trouver un taxi ? ");
		String text = sc.nextLine();

		try {
			int cp = Integer.parseInt(text);
			List<Chauffeur> chauffeursDisponnibles = tcpClient.rechercheTaxi(cp);

			System.out.println("Chauffeurs disponibles: ");

			for (Chauffeur c : chauffeursDisponnibles) {
				System.out.println("[" + c.getVehicule().getNomVehicule() + "]" + c.getNom() + " " + c.getPrenom()
						+ " - " + c.getVehicule().getDescription());
			}

		} catch (NumberFormatException e) {
			System.out.println("Merci de saisir un code postal constitu� de 5 chiffres");
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}
	}

	public static Utilisateur login(Scanner sc) {
		System.out.println("Saisissez votre email");
		String email = sc.nextLine();
		System.out.println("Saisissez un mot de passe");
		String password = sc.nextLine();

		Utilisateur u = null;

		try {
			u = tcpClient.authentification(email, password);
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}

		if (u == null) {
			System.err.println("Echec de l'authentification");
		}

		return u;
	}

	public static void showActions() {
		System.out.println("Que souhaitez vous faire ?");
		System.out.println("1) Creer un compte");
		System.out.println("2) Se connecter");
		System.out.println("0) Quitter l'application");
	}

	public static boolean showActionsClient(Scanner sc) {
		System.out.println("Que souhaitez vous faire ?");
		System.out.println("1) Recherche un taxi");
		System.out.println("0) Quitter l'application");

		int action = Integer.parseInt(sc.nextLine());

		switch (action) {
		case 0:
			return true;
		case 1:
			rechercherTaxi(sc);
			break;
		}

		return false;
	}

	public static boolean showActionsChauffeur(Scanner sc, Utilisateur u) {
		System.out.println("Que souhaitez vous faire ?");
		System.out.println("1) Ajouter un vehicule");
		System.out.println("2) Mettre � jour sa disponibilt�");
		System.out.println("3) Mettre � jour sa position");
		System.out.println("0) Quitter l'application");

		int action = Integer.parseInt(sc.nextLine());

		if (action == 1) {
			creerNouveauVehicule(sc, u.getUsername());
		} else {
			System.err.println("Pas encore impl�ment� !");

		}
		return action == 0;

	}

	public static boolean showActionsAdmin(Scanner sc) {
		System.out.println("Que souhaitez vous faire ?");
		System.out.println("1) Afficher les stats");
		System.out.println("0) Quitter l'application");

		int action = Integer.parseInt(sc.nextLine());

		switch (action) {
		case 0:
			return true;
		case 1:
			afficherStats();
			break;
		}

		return false;
	}

	public static void afficherStats() {
		Stats stats = null;

		try {
			stats = tcpClient.calculerStats();
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}

		if (stats != null) {
			System.out.println(stats);
		} else {
			System.err.println("Erreur lors de la r�cup�ration des stats");
		}
	}

	public static void creerNouveauCompte(Scanner sc) {
		System.out.println("Etes vous..");
		System.out.println("1) Un chauffeur de taxi");
		System.out.println("2) Un client");
		System.out.println("0) Retour au menu");

		int type = Integer.parseInt(sc.nextLine());

		if (type == 0) {
			return;
		}

		if (!(type == 1 || type == 2)) {
			System.err.println("Valeur incorrecte");
			return;
		}

		System.out.println("Saisissez votre nom");
		String nom = sc.nextLine();
		System.out.println("Saisissez votre prenom");
		String prenom = sc.nextLine();
		System.out.println("Saisissez votre adresse");
		String adresse = sc.nextLine();
		System.out.println("Saisissez votre email");
		String email = sc.nextLine();
		System.out.println("Saisissez un mot de passe");
		String password = sc.nextLine();

		try {

			boolean success;

			if (type == 1) {
				int license;
				System.out.println("Saisissez votre numero de license");
				try {
					license = Integer.parseInt(sc.nextLine());
				} catch (NumberFormatException e) {
					System.err.println("Valeur incorrecte");
					return;
				}

				success = tcpClient.creationDeCompteChauffeur(nom, prenom, adresse, email, password, license);
			} else {
				success = tcpClient.creationDeCompteClient(nom, prenom, adresse, email, password);
			}

			if (success) {
				System.out.println("Compte cr�� avec succ�s");
			} else {
				System.out.println("La cr�ation du compte � �chou�");
			}

		} catch (IOException e) {
			System.err.println(e.getMessage());
		}
	}

	public static void creerNouveauVehicule(Scanner sc, String username) {

		System.out.println("Quel type de vehicule souhaitez-vous d�clarer ?");
		System.out.println("1) Voiture");
		System.out.println("2) Moto");
		System.out.println("3) H�licopt�re");
		System.out.println("0) Retour au menu");

		int type = Integer.parseInt(sc.nextLine());

		if (type == 0) {
			return;
		}

		if (type < 1 || type > 3) {
			System.err.println("Valeur incorrecte");
			return;
		}

		VehiculeType vehiculeType;

		switch (type) {
		case 1:
			vehiculeType = VehiculeType.VOITURE;
			break;
		case 2:
			vehiculeType = VehiculeType.MOTO;
			break;
		case 3:
			vehiculeType = VehiculeType.HELICO;
			break;
		default:
			System.err.println("Type de vehicule inconnu");
			return;
		}

		System.out.println("Saisissez la marque du vehicule");
		String marque = sc.nextLine();
		System.out.println("Saisissez le mod�le du vehicule");
		String modele = sc.nextLine();

		String immatriculation = "";
		if (type == 1 || type == 2) {
			System.out.println("Saisissez l'immatriculation du vehicule");
			immatriculation = sc.nextLine();
		}

		int capacite = 0;
		if (type == 1 || type == 3) {
			System.out.println("Saisissez la capacit� du vehicule");
			while (capacite < 1) {
				try {
					capacite = Integer.parseInt(sc.nextLine());
				} catch (NumberFormatException e) {
					capacite = 0;
				}
				
				if(capacite < 1){
					System.err.println("Capacite invalide");
				}
			}
		}

		boolean success;
		try {
			success = tcpClient.creationDeVehicule(vehiculeType, marque, modele, immatriculation, capacite, username);
		} catch (IOException e) {
			e.printStackTrace();
			System.err.println(e.getMessage());
			success = false;
		}

		if (success) {
			System.out.println("Vehicule cr�� avec succ�s");
		} else {
			System.out.println("La cr�ation du vehicule � �chou�");
		}

	}

}
