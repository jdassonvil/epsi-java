package fr.hubert.response;

import fr.hubert.enums.StatusCode;
import fr.hubert.model.Utilisateur;

public class AuthentificationResponse extends GenericResponse {

	// Utile uniquement pour la s�rialization
	private static final long serialVersionUID = 329305166538633357L;
	
	private Utilisateur utilisateur;
	
	public AuthentificationResponse(String message, StatusCode statusCode) {
		super(statusCode, message);
		this.utilisateur = null;
	}
	
	public AuthentificationResponse(String message, StatusCode statusCode, Utilisateur utilisateur) {
		super(statusCode, message);
		this.message = message;
		this.utilisateur = utilisateur;
	}

	public String getMessage() {
		return message;
	}
	
	public Utilisateur getUtilisateur() {
		return utilisateur;
	}

	@Override
	public String toString() {
		return "AuthentificationResponse [message=" + message + ", statusCode=" + statusCode + "]";
	}

}
