package fr.hubert.response;

import fr.hubert.enums.StatusCode;

public class CreationDeCompteResponse extends GenericResponse {

	// Utile uniquement pour la s�rialization
	private static final long serialVersionUID = 7929259283886420320L;

	public CreationDeCompteResponse(StatusCode statusCode, String message) {
		super(statusCode, message);
	}

	@Override
	public String toString() {
		return "CreationDeCompteResponse [toString()=" + super.toString() + "]";
	}
		
}
