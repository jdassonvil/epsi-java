package fr.hubert.response;

import java.io.Serializable;

import fr.hubert.enums.StatusCode;

public class GenericResponse implements Serializable {

	// Utile uniquement pour la s�rialization
	private static final long serialVersionUID = -5546384635679605618L;
	
	protected StatusCode statusCode;
	protected String message;

	public GenericResponse(StatusCode statusCode, String message) {
		super();
		this.statusCode = statusCode;
		this.message = message;
	}

	public StatusCode getStatusCode() {
		return statusCode;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "GenericResponse [statusCode=" + statusCode + ", message=" + message + "]";
	}
	
}
