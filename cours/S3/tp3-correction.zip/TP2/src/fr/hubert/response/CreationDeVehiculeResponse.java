package fr.hubert.response;

import fr.hubert.enums.StatusCode;

// Utile uniquement pour la s�rialization
public class CreationDeVehiculeResponse extends GenericResponse {

	private static final long serialVersionUID = -5043833072266989902L;

	public CreationDeVehiculeResponse(StatusCode statusCode, String message) {
		super(statusCode, message);
	}

	@Override
	public String toString() {
		return "CreationDeCompteResponse [toString()=" + super.toString() + "]";
	}
}
