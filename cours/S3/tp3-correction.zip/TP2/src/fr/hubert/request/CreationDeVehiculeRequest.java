package fr.hubert.request;

import fr.hubert.enums.VehiculeType;

public class CreationDeVehiculeRequest extends GenericRequest {

	// Utile uniquement pour la s�rialization
	private static final long serialVersionUID = 5522767614122655651L;

	private VehiculeType type;
	private String marque;
	private String modele;
	private String immatriculation;
	private int capacite;

	private String username;

	public CreationDeVehiculeRequest(VehiculeType type, String marque, String modele, String immatricualtion,
			int capacite, String username) {
		super();
		this.type = type;
		this.marque = marque;
		this.modele = modele;
		this.username = username;
		this.capacite = capacite;
		this.immatriculation = immatricualtion;
	}

	public VehiculeType getType() {
		return type;
	}

	public String getUsername() {
		return username;
	}

	public String getMarque() {
		return marque;
	}

	public String getModele() {
		return modele;
	}

	public int getCapacite() {
		return capacite;
	}

	public String getImmatriculation() {
		return immatriculation;
	}

	@Override
	public String toString() {
		return "CreationDeVehiculeRequest [type=" + type + ", marque=" + marque + ", modele=" + modele
				+ ", immatriculation=" + immatriculation + ", capacite=" + capacite + ", username=" + username + "]";
	}

}
