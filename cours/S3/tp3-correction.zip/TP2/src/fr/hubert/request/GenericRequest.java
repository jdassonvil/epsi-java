package fr.hubert.request;

import java.io.Serializable;

public abstract class GenericRequest implements Serializable {

	// Utile uniquement pour la s�rialization
	private static final long serialVersionUID = -391942372691391158L;

}
