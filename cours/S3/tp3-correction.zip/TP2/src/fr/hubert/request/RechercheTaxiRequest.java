package fr.hubert.request;

public class RechercheTaxiRequest extends GenericRequest {

	// Utile uniquement pour la s�rialization
	private static final long serialVersionUID = 2794710538118948745L;

	private int position;

	public RechercheTaxiRequest(int position) {
		super();
		this.position = position;
	}

	public int getPosition() {
		return position;
	}
	
	
}
