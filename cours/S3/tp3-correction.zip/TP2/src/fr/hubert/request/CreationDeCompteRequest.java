package fr.hubert.request;

import fr.hubert.enums.UserType;

public class CreationDeCompteRequest extends GenericRequest {

	// Utile uniquement pour la s�rialization
	private static final long serialVersionUID = -5023200414969514793L;

	private UserType userType;

	private String email;
	private String password;
	private String nom;
	private String prenom;
	private String adresse;
	private int license;

	// Construit une requ�te de cr�ation de client
	public CreationDeCompteRequest(String nom, String prenom,  String adresse, String email, String password) {
		super();
		this.userType = UserType.CLIENT;
		this.email = email;
		this.password = password;
		this.nom = nom;
		this.prenom = prenom;
		this.adresse = adresse;
	}

	// Construit une requ�te de cr�ation de chauffeurs
	public CreationDeCompteRequest(String nom, String prenom,  String adresse, String email, String password,
			int license) {
		super();
		this.userType = UserType.CHAUFFEUR;
		this.email = email;
		this.password = password;
		this.nom = nom;
		this.prenom = prenom;
		this.adresse = adresse;
		this.license = license;
	}

	public UserType getUserType() {
		return userType;
	}

	public void setUserType(UserType userType) {
		this.userType = userType;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getAdresse() {
		return adresse;
	}

	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}

	public int getLicense() {
		return license;
	}

	public void setLicense(short license) {
		this.license = license;
	}

	@Override
	public String toString() {
		return "CreationDeCompteRequest [userType=" + userType + ", email=" + email + ", password=" + password
				+ ", nom=" + nom + ", prenom=" + prenom + ", adresse=" + adresse + ", license=" + license + "]";
	}
		
}
