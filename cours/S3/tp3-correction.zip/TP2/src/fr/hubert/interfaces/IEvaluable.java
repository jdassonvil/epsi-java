package fr.hubert.interfaces;

import java.util.List;

import fr.hubert.exception.AucuneEvaluationException;
import fr.hubert.model.Evaluation;

public interface IEvaluable {
	
	public void setEvaluation(Evaluation e);

	public int getEvaluationMoyenne() throws AucuneEvaluationException;

	public List<Evaluation> getEvaluations();
}
