package fr.hubert.model;

import fr.hubert.enums.VehiculeType;

public class Voiture extends Vehicule {

	// Utile uniquement pour la s�rialization
	private static final long serialVersionUID = -4522100371374190750L;

	private String immatriculation;
	
	// Tarif en � au km
	private static float TARIF = 1.5f;
	
	public Voiture(String marque, String modele, int capacite,
			String immatriculation) {
		super(VehiculeType.VOITURE, marque, modele, capacite);
		this.immatriculation = immatriculation;
	}

	public String getImmatriculation() {
		return immatriculation;
	}
	
	@Override
	public float getTarif() {
		return TARIF;
	}
	
	@Override
	public String getDescription() {
		return this.getMarque() + " " + this.getModele() + " pour " + this.capacite + " personne(s)";
	}

}
