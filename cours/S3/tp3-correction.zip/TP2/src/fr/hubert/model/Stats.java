package fr.hubert.model;

import java.io.Serializable;

public class Stats implements Serializable {

	// Utile uniquement pour la s�rialization
	private static final long serialVersionUID = -2317254664136584265L;

	private int nbUtilisateurs;
	private int nbMoto;
	private int nbVoiture;
	private int nbHelico;

	public int getNbUtilisateurs() {
		return nbUtilisateurs;
	}

	public void setNbUtilisateurs(int nbUtilisateurs) {
		this.nbUtilisateurs = nbUtilisateurs;
	}

	public int getNbMoto() {
		return nbMoto;
	}

	public void setNbMoto(int nbMoto) {
		this.nbMoto = nbMoto;
	}

	public int getNbVoiture() {
		return nbVoiture;
	}

	public void setNbVoiture(int nbVoiture) {
		this.nbVoiture = nbVoiture;
	}

	public int getNbHelico() {
		return nbHelico;
	}

	public void setNbHelico(int nbHelico) {
		this.nbHelico = nbHelico;
	}

	@Override
	public String toString() {
		return "Nombre d'utilisateurs: " + this.nbUtilisateurs + "\nNombre de moto: " + this.nbMoto
				+ "\nNombre de voiture: " + this.nbVoiture + "\nNombre d'helicoptere: " + this.nbHelico + "\n";
	}

}
