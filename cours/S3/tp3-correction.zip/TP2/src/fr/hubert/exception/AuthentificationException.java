package fr.hubert.exception;

public class AuthentificationException extends Exception {

	// Utile uniquement pour la s�rialization
	private static final long serialVersionUID = -9048749705917048456L;

}
