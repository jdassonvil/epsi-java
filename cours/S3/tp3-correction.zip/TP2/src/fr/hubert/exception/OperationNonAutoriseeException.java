package fr.hubert.exception;

public class OperationNonAutoriseeException extends Exception {

	// Utile uniquement pour la s�rialization
	private static final long serialVersionUID = -6965312169227024319L;

}
