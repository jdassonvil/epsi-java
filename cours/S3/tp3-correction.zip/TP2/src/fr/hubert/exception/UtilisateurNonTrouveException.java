package fr.hubert.exception;

public class UtilisateurNonTrouveException extends Exception {

	// Utile uniquement pour la s�rialization
	private static final long serialVersionUID = 3772239888845473266L;

}
