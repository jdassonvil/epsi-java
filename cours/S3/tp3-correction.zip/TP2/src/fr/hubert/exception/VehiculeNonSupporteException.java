package fr.hubert.exception;

public class VehiculeNonSupporteException extends Exception {

	// Utile uniquement pour la s�rialization
	private static final long serialVersionUID = 731029415971291217L;

}
