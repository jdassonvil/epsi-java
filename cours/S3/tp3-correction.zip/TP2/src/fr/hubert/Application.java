package fr.hubert;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import fr.hubert.enums.VehiculeType;
import fr.hubert.exception.AuthentificationException;
import fr.hubert.exception.OperationNonAutoriseeException;
import fr.hubert.exception.TaxiNonTrouveException;
import fr.hubert.exception.UtilisateurDejaExistantException;
import fr.hubert.exception.UtilisateurNonTrouveException;
import fr.hubert.exception.VehiculeNonSupporteException;
import fr.hubert.model.Admin;
import fr.hubert.model.Chauffeur;
import fr.hubert.model.Client;
import fr.hubert.model.Helicoptere;
import fr.hubert.model.Moto;
import fr.hubert.model.Utilisateur;
import fr.hubert.model.Voiture;

public class Application {

	private static Map<String, Utilisateur> utilisateurs = new HashMap<String, Utilisateur>();
	private static String DATA_PATH = "C:/tmp/java/utilsateurs.ser";

	// Charge les utilisateurs depuis le disque
	@SuppressWarnings("unchecked")
	public static void chargerUtilisateurs() {
		File f = new File(DATA_PATH);

		if (f.exists()) {
			ObjectInputStream ois = null;

			try {
				// Lecture de la collection d'utilisateurs
				ois = new ObjectInputStream(new FileInputStream(f));
				utilisateurs = (HashMap<String, Utilisateur>) ois.readObject();
			} catch (IOException e) {
				System.err.println("Erreur au chargement des utilsateurs: " + e.getMessage());
			} catch (ClassNotFoundException e) {
				System.out.println("La classe charg�e est inconnue " + e.getMessage());
			} finally {
				if (ois != null) {
					try {
						ois.close();
					} catch (IOException e) {
						System.err.println(e.getMessage());
					}
				}
			}
		} else {
			System.out.println("Le fichier de sauvegarde des utilisateurs n'existe pas");
		}
	}

	// Sauvegarde les utilisateurs sur le disque
	public static void sauvegarderUtilisateurs() {
		File f = new File(DATA_PATH);

		// Suppresion du fichier s'il existe d�j�
		if (f.exists()) {
			f.delete();
		}

		try {
			// Cr�ation du r�pertoire de destination
			new File("C:/tmp/java").mkdirs();
			// Cr�ation du fichier
			f.createNewFile();
		} catch (IOException e1) {
			System.err.println("Impossible de cr�er le fichier de sauvegarde");
			return;
		}

		ObjectOutputStream oos = null;
		try {
			oos = new ObjectOutputStream(new FileOutputStream(f));
			// Ecriture de la collection d'utilisateurs
			oos.writeObject(utilisateurs);
		} catch (FileNotFoundException e) {
			System.err.println(e.getMessage());
		} catch (IOException e) {
			System.err
					.println("Erreur lors de l'�criture dans le fichier " + f.getAbsolutePath() + " " + e.getMessage());
		} finally {
			if (oos != null) {
				try {
					oos.close();
				} catch (IOException e) {
					System.err.println(e.getMessage());
				}
			}
		}
	}

	private static Utilisateur trouverUtilisateur(String username) {
		
		return utilisateurs.get(username);
		
	}

	public static Client creerCompteClient(String nom, String prenom, String adresse, String email, String password)
			throws UtilisateurDejaExistantException {

		if (trouverUtilisateur(email) != null) {
			throw new UtilisateurDejaExistantException();
		}

		Client c = new Client(nom, prenom, adresse, email, password);
		utilisateurs.put(email, c);
		sauvegarderUtilisateurs();
		return c;
	}

	public static Chauffeur creerCompteChauffeur(String nom, String prenom, String adresse, String email,
			String password, int license) throws UtilisateurDejaExistantException {

		if (trouverUtilisateur(email) != null) {
			throw new UtilisateurDejaExistantException();
		}

		Chauffeur c = new Chauffeur(nom, prenom, adresse, email, password, license);
		utilisateurs.put(email, c);
		sauvegarderUtilisateurs();
		return c;
	}

	public static Admin creerCompteAdmin(String email, String password) throws UtilisateurDejaExistantException {

		if (trouverUtilisateur(email) != null) {
			throw new UtilisateurDejaExistantException();
		}

		Admin a = new Admin(email, password);
		utilisateurs.put(email, a);
		sauvegarderUtilisateurs();
		return a;
	}

	public static Utilisateur authentifie(String username, String password) throws AuthentificationException {
		Utilisateur u = trouverUtilisateur(username);

		if (u == null) {
			throw new AuthentificationException();
		}

		if (!u.checkPassword(password)) {
			throw new AuthentificationException();
		}

		return u;
	}
	
	public static void ajouterVehicule(String username, VehiculeType type, int capacite, String marque,
			String modele, String immatriculation)
					throws OperationNonAutoriseeException, UtilisateurNonTrouveException, VehiculeNonSupporteException{
		Utilisateur u = trouverUtilisateur(username);
		
		if(u == null){
			throw new UtilisateurNonTrouveException();
		}
		
		if(! (u instanceof Chauffeur)){
			throw new OperationNonAutoriseeException();
		}
		
		Chauffeur c = (Chauffeur)u;
		
		switch(type){
		case VOITURE:
			c.setVehicule(new Voiture(marque, modele, capacite, immatriculation));
			break;
		case MOTO:
			c.setVehicule(new Moto(marque, modele, immatriculation));
			break;
		case HELICO:
			c.setVehicule(new Helicoptere(marque, modele, capacite));
			break;
		default:
			throw new VehiculeNonSupporteException();
		}
			
	}

	public static List<Chauffeur> trouverTaxi(int position) throws TaxiNonTrouveException {

		List<Chauffeur> chauffeursDisponibles = new ArrayList<>();

		for (Utilisateur u : utilisateurs.values()) {
			if (u instanceof Chauffeur) {
				Chauffeur c = (Chauffeur) u;
				if (c.getPosition() == position && c.estDisponible() && c.getVehicule() != null) {
					chauffeursDisponibles.add(c);
				}
			}
		}

		if (chauffeursDisponibles.size() == 0) {
			throw new TaxiNonTrouveException();
		}

		return chauffeursDisponibles;
	}

	public static int nbUtilisateurs() {
		return utilisateurs.size();
	}

	public static int nbMoto() {
		int nbMoto = 0;
		for (Utilisateur u : utilisateurs.values()) {
			if (u instanceof Chauffeur && ((Chauffeur) u).getVehicule() instanceof Moto) {
				nbMoto++;
			}
		}

		return nbMoto;
	}

	public static int nbHelico() {
		int nbHelico = 0;
		for (Utilisateur u : utilisateurs.values()) {
			if (u instanceof Chauffeur && ((Chauffeur) u).getVehicule() instanceof Helicoptere) {
				nbHelico++;
			}
		}

		return nbHelico;
	}

	public static int nbVoiture() {
		int nbVoiture = 0;
		for (Utilisateur u : utilisateurs.values()) {
			if (u instanceof Chauffeur && ((Chauffeur) u).getVehicule() instanceof Voiture) {
				nbVoiture++;
			}
		}

		return nbVoiture;
	}

}
