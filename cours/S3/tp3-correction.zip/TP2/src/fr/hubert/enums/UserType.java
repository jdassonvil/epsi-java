package fr.hubert.enums;

public enum UserType {

	ADMIN, CLIENT, CHAUFFEUR;

}
