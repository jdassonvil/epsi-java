package fr.hubert.enums;

public enum VehiculeType {
	CAMION("Camion"), HELICO("Helicopt�re"), MOTO("moto"), VOITURE("voiture");

	private String type;

	private VehiculeType(String type) {
		this.type = type;
	}

	public String getValue() {
		return this.type;
	}

}
