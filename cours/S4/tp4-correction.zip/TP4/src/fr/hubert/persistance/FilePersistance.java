package fr.hubert.persistance;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import fr.hubert.exception.UtilisateurDejaExistantException;
import fr.hubert.interfaces.ISourceDeDonnee;
import fr.hubert.model.Admin;
import fr.hubert.model.Chauffeur;
import fr.hubert.model.Client;
import fr.hubert.model.Utilisateur;

public class FilePersistance implements ISourceDeDonnee {

	private static String DATA_PATH = "C:/tmp/java/utilsateurs.ser";

	private List<Utilisateur> utilisateurs = new ArrayList<Utilisateur>();
	private boolean charge = false;

	@SuppressWarnings("unchecked")
	@Override
	public List<Utilisateur> chargerUtilisateurs() {
		File f = new File(DATA_PATH);

		if (f.exists()) {
			ObjectInputStream ois = null;

			try {
				// Lecture de la collection d'utilisateurs
				ois = new ObjectInputStream(new FileInputStream(f));
				this.utilisateurs = (ArrayList<Utilisateur>) ois.readObject();
				this.charge = true;
			} catch (IOException e) {
				System.err.println("Erreur au chargement des utilsateurs: " + e.getMessage());
			} catch (ClassNotFoundException e) {
				System.out.println("La classe charg�e est inconnue " + e.getMessage());
			} finally {
				if (ois != null) {
					try {
						ois.close();
					} catch (IOException e) {
						System.err.println(e.getMessage());
					}
				}
			}
		} else {
			System.out.println("Le fichier de sauvegarde des utilisateurs n'existe pas");

		}

		// En cas d'erreur ou de fichier absent on renvoi une liste vide
		return this.utilisateurs;

	}

	@Override
	public Utilisateur trouverUtilisateur(String username) {

		if (!charge) {
			this.chargerUtilisateurs();
		}

		for (Utilisateur u : this.utilisateurs) {
			if (u.getUsername().equals(username)) {
				return u;
			}
		}

		return null;

	}

	// Sauvegarde les utilisateurs sur le disque
	private void sauvegarderUtilisateurs() {
		File f = new File(DATA_PATH);

		// Suppresion du fichier s'il existe d�j�
		if (f.exists()) {
			f.delete();
		}

		try {
			// Cr�ation du r�pertoire de destination
			new File("C:/tmp/java").mkdirs();
			// Cr�ation du fichier
			f.createNewFile();
		} catch (IOException e1) {
			System.err.println("Impossible de cr�er le fichier de sauvegarde");
			return;
		}

		ObjectOutputStream oos = null;
		try {
			oos = new ObjectOutputStream(new FileOutputStream(f));
			// Ecriture de la collection d'utilisateurs
			oos.writeObject(utilisateurs);
		} catch (FileNotFoundException e) {
			System.err.println(e.getMessage());
		} catch (IOException e) {
			System.err
					.println("Erreur lors de l'�criture dans le fichier " + f.getAbsolutePath() + " " + e.getMessage());
		} finally {
			if (oos != null) {
				try {
					oos.close();
				} catch (IOException e) {
					System.err.println(e.getMessage());
				}
			}
		}
	}

	@Override
	public Client creerCompteClient(String nom, String prenom, String adresse, String email, String password) {

		if (!charge) {
			this.chargerUtilisateurs();
		}

		Client c = new Client(nom, prenom, adresse, email, password);
		utilisateurs.add(c);
		sauvegarderUtilisateurs();
		return c;
	}

	@Override
	public Chauffeur creerCompteChauffeur(String nom, String prenom, String adresse, String email, String password,
			int license) {

		if (!charge) {
			this.chargerUtilisateurs();
		}

		Chauffeur c = new Chauffeur(nom, prenom, adresse, email, password, license);
		utilisateurs.add(c);
		sauvegarderUtilisateurs();
		return c;
	}

	@Override
	public Admin creerCompteAdmin(String email, String password) throws UtilisateurDejaExistantException {

		if (!charge) {
			this.chargerUtilisateurs();
		}

		Admin a = new Admin(email, password);
		utilisateurs.add(a);
		sauvegarderUtilisateurs();
		return a;
	}

}
