package fr.hubert.persistance;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import fr.hubert.enums.UserType;
import fr.hubert.interfaces.ISourceDeDonnee;
import fr.hubert.model.Admin;
import fr.hubert.model.Chauffeur;
import fr.hubert.model.Client;
import fr.hubert.model.Utilisateur;

public class DatabasePersistance implements ISourceDeDonnee {

	private static final String DB_NAME = "hubert";
	private static final String DB_HOST = "localhost";
	private static final int DB_PORT = 3306;
	private static final String DB_USER = "root";
	private static final String DB_PWD = "";

	private Connection conn;

	public DatabasePersistance() {
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			System.out.println("JDBC driver successfuly loaded");
		} catch (Exception e) {
			throw new RuntimeException("Driver mysql absent");
		}
	}

	private void initConnection() {
		try {
			this.conn = DriverManager.getConnection("jdbc:mysql://" + DB_HOST + ":" + DB_PORT + "/" + DB_NAME, DB_USER,
					DB_PWD);
		} catch (SQLException e) {
			System.err.println("La connexion ne peut pas �tre obtenue: " + e.getMessage());
		}

	}

	private void closeConnection() {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				conn = null;
			}
		}
	}

	private ResultSet executerSelect(String request) {

		initConnection();

		if (this.conn == null) {
			return null;
		}

		System.out.println("Requ�te SQL: " + request);

		try {
			Statement s = this.conn.createStatement();
			return s.executeQuery(request);
		} catch (SQLException e) {
			System.err.println("Erreur lors de l'ex�cution de la requ�te: " + e.getMessage());
			return null;
		}

	}

	private void executerUpdate(String request) {
		initConnection();

		System.out.println("Requ�te SQL: " + request);

		if (conn != null) {

			try {
				Statement s = conn.createStatement();
				s.executeUpdate(request);
			} catch (SQLException e) {
				System.err.println("Erreur lors de l'ex�cution de la requ�te: " + e.getMessage());
			}
		}

	}

	private Utilisateur getUtilisateur(ResultSet resultSet) throws SQLException {
		UserType userType = UserType.fromInteger(resultSet.getInt("type"));

		switch (userType) {
		case CLIENT:
			return new Client(resultSet.getString("NOM"), resultSet.getString("PRENOM"), resultSet.getString("ADRESSE"),
					resultSet.getString("EMAIL"), resultSet.getString("PASSWORD"));
		case CHAUFFEUR:
			return new Chauffeur(resultSet.getString("NOM"), resultSet.getString("PRENOM"),
					resultSet.getString("ADRESSE"), resultSet.getString("EMAIL"), resultSet.getString("PASSWORD"),
					resultSet.getInt("LICENSE"));
		case ADMIN:
			return new Admin(resultSet.getString("EMAIL"), resultSet.getString("PASSWORD"));
		default:
			return null;
		}

	}

	public List<Utilisateur> chargerUtilisateurs() {

		final String request = "SELECT * FROM utilisateur";

		ResultSet resultSet = executerSelect(request);

		List<Utilisateur> resultat = new ArrayList<Utilisateur>();

		if (resultSet != null) {

			try {
				while (resultSet.next()) {
					resultat.add(getUtilisateur(resultSet));
				}
			} catch (SQLException e) {
				System.err.println(e.getMessage());
			}
		}

		closeConnection();
		return resultat;
	}

	@Override
	public Utilisateur trouverUtilisateur(String username) {
		final String request = "SELECT * FROM utilisateur WHERE email = '" + username + "'";

		ResultSet resultSet = executerSelect(request);

		try {
			if (resultSet != null && resultSet.next()) {
				return getUtilisateur(resultSet);
			}
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}

		closeConnection();
		return null;
	}

	@Override
	public Client creerCompteClient(String nom, String prenom, String adresse, String email, String password) {

		String request = "INSERT INTO utilisateur(id, TYPE, NOM, PRENOM, ADRESSE, EMAIL, PASSWORD) " + "VALUES(null,"
				+ UserType.CLIENT.getIntValue() + ",'" + nom + "','" + prenom + "','" + adresse + "','" + email + "','"
				+ password + "')";

		this.executerUpdate(request);
		closeConnection();
		return new Client(nom, prenom, adresse, email, password);
	}

	@Override
	public Chauffeur creerCompteChauffeur(String nom, String prenom, String adresse, String email, String password,
			int license) {

		String request = "INSERT INTO utilisateur(id, TYPE, NOM, PRENOM, ADRESSE, EMAIL, PASSWORD, LICENSE, POSITION, DISPONIBLE)"
				+ "VALUES(null," + UserType.CLIENT.getIntValue() + ",'" + nom + "','" + prenom + "','" + adresse + "','"
				+ email + "','" + password + "'," + license + ")";

		this.executerUpdate(request);
		closeConnection();
		return new Chauffeur(nom, prenom, adresse, email, password, license);
	}

	@Override
	public Admin creerCompteAdmin(String email, String password) {

		String request = "INSERT INTO utilisateur(id, TYPE, EMAIL, PASSWORD) " + "VALUES(null,"
				+ UserType.ADMIN.getIntValue() + ",'" + email + "','" + password + "')";

		this.executerUpdate(request);
		closeConnection();
		return new Admin(email, password);
	}

}
