package fr.hubert.request;

public class StatsRequest extends GenericRequest{

	// Utile uniquement pour la s�rialization
	private static final long serialVersionUID = -2438893568597192366L;
	

}
