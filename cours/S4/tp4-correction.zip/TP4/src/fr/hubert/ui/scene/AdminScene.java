package fr.hubert.ui.scene;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;

public class AdminScene extends RootScene{

	
	public AdminScene() {
		
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(this.getClass().getResource("../view/AdminView.fxml"));
		
		try{
			rootLayout.setCenter(loader.load());
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	public Scene getScene() {
		return scene;
	}

}
