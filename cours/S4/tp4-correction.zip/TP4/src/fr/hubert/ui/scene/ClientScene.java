package fr.hubert.ui.scene;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;

public class ClientScene extends RootScene{

	
	public ClientScene() {
		
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(this.getClass().getResource("../view/ClientView.fxml"));
		
		try{
			rootLayout.setCenter(loader.load());
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	public Scene getScene() {
		return scene;
	}

}
