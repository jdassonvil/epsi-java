package fr.hubert.ui.scene;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;

public class RootScene {

	protected Scene scene;
	protected BorderPane rootLayout;

	public RootScene() {

		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("../view/RootLayout.fxml"));

		try {
			this.rootLayout = (BorderPane) loader.load();
			this.scene = new Scene(rootLayout);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public Scene getScene() {
		return scene;
	}

}
