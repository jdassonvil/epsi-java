package fr.hubert.ui.scene;

import java.io.IOException;

import fr.hubert.ui.controller.LoginController;
import javafx.fxml.FXMLLoader;

public class LoginScene extends RootScene {

	public LoginScene() {
		super();
		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("../view/LoginView.fxml"));
		fxmlLoader.setController(new LoginController());

		try {
			rootLayout.setCenter(fxmlLoader.load());
		} catch (IOException exception) {
			throw new RuntimeException(exception);
		}
	}

}
