package fr.hubert.ui.controller;

import java.io.IOException;

import fr.hubert.app.TCPClient;
import fr.hubert.model.Utilisateur;
import fr.hubert.ui.Graphic;
import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;

public class LoginController {

	@FXML
	private TextField usernameField;
	@FXML
	private PasswordField passwordField;
	@FXML
	private Text feedback;
	
	private TCPClient tcpClient = new TCPClient();

	@FXML
	public void handleSubmit() {

		String username = usernameField.getText();
		String password = passwordField.getText();

		if (username == null || username.isEmpty() || password == null || password.isEmpty()) {
			feedback.setText("Le nom d'utilisateur et le mot de passe doivent �tre renseign�");
			return;
		}

		Utilisateur u = null;

		try {
			u = tcpClient.authentification(username, password);
			Graphic.redirectUser(u);
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}

		if (u == null) {
			feedback.setText("Echec de l'authentification");
		}
	}

}
