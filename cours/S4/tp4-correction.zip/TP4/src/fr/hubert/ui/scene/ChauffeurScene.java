package fr.hubert.ui.scene;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;

public class ChauffeurScene extends RootScene{

	
	public ChauffeurScene() {
		
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(this.getClass().getResource("../view/ChauffeurView.fxml"));
		
		try{
			rootLayout.setCenter(loader.load());
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	public Scene getScene() {
		return scene;
	}

}
