package fr.hubert.ui;

import fr.hubert.model.Admin;
import fr.hubert.model.Chauffeur;
import fr.hubert.model.Client;
import fr.hubert.model.Utilisateur;
import fr.hubert.ui.scene.AdminScene;
import fr.hubert.ui.scene.ChauffeurScene;
import fr.hubert.ui.scene.ClientScene;
import fr.hubert.ui.scene.LoginScene;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;

public class Graphic extends Application {

	private static Stage stage;

	@Override
	public void start(Stage primaryStage) throws Exception {

		stage = primaryStage;
		stage.setTitle("Hubert client");

		stage.setScene(new LoginScene().getScene());
		stage.show();
	}

	public static void redirectUser(Utilisateur utilisateur) {

		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Graphic.class.getResource("view/RootLayout.fxml"));
		System.out.println(utilisateur);
		if (utilisateur instanceof Client) {
			stage.setScene(new ClientScene().getScene());
		} else if (utilisateur instanceof Chauffeur) {
			stage.setScene(new ChauffeurScene().getScene());
		} else if (utilisateur instanceof Admin) {
			stage.setScene(new AdminScene().getScene());
		}
	}

	public static void launch() {
		Application.launch(Graphic.class);
	}

}
