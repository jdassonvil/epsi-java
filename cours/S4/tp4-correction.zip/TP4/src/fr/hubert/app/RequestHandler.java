package fr.hubert.app;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;

import fr.hubert.enums.StatusCode;
import fr.hubert.exception.AuthentificationException;
import fr.hubert.exception.OperationNonAutoriseeException;
import fr.hubert.exception.TaxiNonTrouveException;
import fr.hubert.exception.UtilisateurDejaExistantException;
import fr.hubert.exception.UtilisateurNonTrouveException;
import fr.hubert.exception.VehiculeNonSupporteException;
import fr.hubert.model.Chauffeur;
import fr.hubert.model.Stats;
import fr.hubert.model.Utilisateur;
import fr.hubert.request.AuthentificationRequest;
import fr.hubert.request.CreationDeCompteRequest;
import fr.hubert.request.CreationDeVehiculeRequest;
import fr.hubert.request.RechercheTaxiRequest;
import fr.hubert.request.StatsRequest;
import fr.hubert.response.AuthentificationResponse;
import fr.hubert.response.CreationDeCompteResponse;
import fr.hubert.response.CreationDeVehiculeResponse;
import fr.hubert.response.GenericResponse;
import fr.hubert.response.RechercheTaxiResponse;
import fr.hubert.response.StatsResponse;

public class RequestHandler implements Runnable {

	private Socket s;

	public RequestHandler(Socket s) {
		this.s = s;
	}

	@Override
	public void run() {

		ObjectInputStream ois = null;
		ObjectOutputStream oos = null;

		System.out.println("[Server] Requ�te prise en charge par le thread " + Thread.currentThread().getId());

		// Simulation d'un temps de traitement de 5 secondes
		// Thread.sleep(5000);

		try {
			ois = new ObjectInputStream(s.getInputStream());
			Object request = ois.readObject();

			oos = new ObjectOutputStream(s.getOutputStream());

			// Gestion des differents type de req�te
			if (request instanceof AuthentificationRequest) {
				handleAuthentification((AuthentificationRequest) request, oos);
			} else if (request instanceof RechercheTaxiRequest) {
				handleRechercheTaxi((RechercheTaxiRequest) request, oos);
			} else if (request instanceof CreationDeCompteRequest) {
				handleCreationDeCompte((CreationDeCompteRequest) request, oos);
			} else if (request instanceof StatsRequest) {
				handleCalculStat(oos);
			} else if (request instanceof CreationDeVehiculeRequest) {
				handleCreationDeVehicule((CreationDeVehiculeRequest) request, oos);
			} else {
				// Lorsque la requ�te est inconnue on renvoi une erreur g�n�rique
				System.out.println("[Server] Requ�te inconnue " + request.getClass());
				oos.writeObject(new GenericResponse(StatusCode.BAD_REQUEST, "Requ�te inconnue"));
			}

		} catch (IOException e) {
			System.err.println("Erreur lors du traitement d'une requ�te: " + e.getMessage());
		} catch (ClassNotFoundException e) {
			System.err.println(e.getMessage());
		} finally {
			// Fermeture de la socket et des flux
			try {
				if (s != null) {
					s.close();
				}

				if (ois != null) {
					ois.close();
				}

				if (oos != null) {
					oos.close();
				}
			} catch (IOException e) {
				System.err.println(e.getMessage());
			}
		}

	}

	// Gestion d'une requ�te d'authentification
	public void handleAuthentification(AuthentificationRequest request, ObjectOutputStream oos) throws IOException {
		System.out.println("[Server] Traitement d'une requ�te d'authentification");
		try {
			Utilisateur u = Actions.authentifie(request.getUsername(), request.getPassword());
			System.out.println("Utilisateur authentifie");
			oos.writeObject(new AuthentificationResponse("Utilisateur authentifi�", StatusCode.OK, u));
		} catch (AuthentificationException e) {
			System.out.println("Echec de l'authentification");
			oos.writeObject(new AuthentificationResponse("Echec de l'authentification", StatusCode.BAD_CREDENTIALS));
		}

	}

	// Gestion d'une requ�te de recherche
	public void handleRechercheTaxi(RechercheTaxiRequest request, ObjectOutputStream oos) throws IOException {
		System.out.println("[Server] Traitement d'une requ�te de recherche");

		try {
			List<Chauffeur> chauffeurs = Actions.trouverTaxi(request.getPosition());
			oos.writeObject(new RechercheTaxiResponse(StatusCode.OK, "1 chauffeur ou plus disponbile", chauffeurs));
		} catch (TaxiNonTrouveException e) {
			oos.writeObject(new RechercheTaxiResponse(StatusCode.OK, "Aucun chauffeur disponible"));
		}
	}

	// Gestion d'une requ�te de cr�ation de compte
	public void handleCreationDeCompte(CreationDeCompteRequest request, ObjectOutputStream oos) throws IOException {
		System.out.println("[Server] Traitement d'une de cr�ation de compte");

		try {
			switch (request.getUserType()) {
			case CLIENT:
				Actions.creerCompteClient(request.getNom(), request.getPrenom(), request.getAdresse(),
						request.getEmail(), request.getPassword());
				break;
			case CHAUFFEUR:
				Actions.creerCompteChauffeur(request.getNom(), request.getPrenom(), request.getAdresse(),
						request.getEmail(), request.getPassword(), request.getLicense());
				break;
			case ADMIN:
				// On ne permet pas la cr�ation de compte admin depuis l'API
				// (trop dangereux)
				throw new OperationNonAutoriseeException();
			}

			oos.writeObject(new CreationDeCompteResponse(StatusCode.OK, "Utilisateur cr�� avec succ�s"));

		} catch (UtilisateurDejaExistantException e) {
			oos.writeObject(
					new CreationDeCompteResponse(StatusCode.ALREADY_EXIST, "Nom d'utilsateur (email) d�j� utilis�"));
		} catch (OperationNonAutoriseeException e) {
			oos.writeObject(new CreationDeCompteResponse(StatusCode.BAD_REQUEST,
					"Impossible de cr�er un compte admin via l'API"));
		}
	}

	// Gestion d'une requ�te de cr�ation de v�hicule
	public void handleCreationDeVehicule(CreationDeVehiculeRequest request, ObjectOutputStream oos) throws IOException {
		System.out.println("[Server] Traitement d'une de cr�ation de vehicule");

		try {
			Actions.ajouterVehicule(request.getUsername(), request.getType(), request.getCapacite(),
					request.getMarque(), request.getModele(), request.getImmatriculation());
			oos.writeObject(new CreationDeVehiculeResponse(StatusCode.OK, "Cr�ation d'un nouveau vehicule r�ussi"));
		} catch (OperationNonAutoriseeException e) {
			oos.writeObject(new CreationDeVehiculeResponse(StatusCode.BAD_IDENTITY,
					"Cette op�ration est reserv�e aux chauffeurs"));
		} catch (VehiculeNonSupporteException e) {
			oos.writeObject(new CreationDeVehiculeResponse(StatusCode.BAD_REQUEST,
					"Ce type vehicule n'est pas encore support� par l'application"));
		} catch (UtilisateurNonTrouveException e) {
			oos.writeObject(new CreationDeVehiculeResponse(StatusCode.BAD_CREDENTIALS, "L'utilisateur est inconnu"));
		}

	}

	public void handleCalculStat(ObjectOutputStream oos) throws IOException {
		System.out.println("[Server] Traitement d'une requpete de calcul de stats");

		Stats stats = new Stats();
		stats.setNbUtilisateurs(Actions.nbUtilisateurs());
		stats.setNbMoto(Actions.nbMoto());
		stats.setNbVoiture(Actions.nbVoiture());
		stats.setNbHelico(Actions.nbHelico());

		oos.writeObject(new StatsResponse(StatusCode.OK, "statistiques ok", stats));
	}
}
