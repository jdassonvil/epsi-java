package fr.hubert.app;

import java.util.Scanner;

import fr.hubert.exception.UtilisateurDejaExistantException;
import fr.hubert.ui.Console;
import fr.hubert.ui.Graphic;

public class Main {

	public static void main(String[] args) {
		
		if (args.length > 0 && "-s".equals(args[0])) {
			System.out.println("Application Hubert en mode server");
					
			// Cr�ation d'un compte de test admin/admin s'il n'existe pas d�j�
			try {
				Actions.creerCompteAdmin("admin", "admin");
			} catch (UtilisateurDejaExistantException e) {
				// Rien � faire si le compte existe d�j�
			}
			
			Server server = new Server();
			server.start();
		} else if( args.length > 0 && "--console".equals(args[0]) ) {
			System.out.println("Application Hubert en mode client");
			Scanner sc = new Scanner(System.in);

			Console.showMenu(sc);
			sc.close();
		}else{
			Graphic.launch();
		}

		System.out.println("bye bye");

	}
	
	/*public static void creerJeuDeTest() {
	// Jeu de test
	try {
		// Comptes client
		Application.creerCompteClient("Depardieu", "Gerard", "Quelque part en belgique",
				"gerard.depardieu@gmail.com", "bxfr37");

		Application.creerCompteClient("Patrick", "Sebastien", "rue garibaldi", "sebastien.patrick@yahoo.com",
				"bxfr37");

		Application.creerCompteClient("test", "test", "test", "test@test.com", "test");

		// Comptes chauffeur
		Chauffeur c1 = Application.creerCompteChauffeur("Paul", "DeuxMaisons", "12 avenue de le republique",
				"pdemaisons@outlook.com", "ptaxi", (short) 28984849);
		c1.setPosition(69006);
		c1.setVehicule(new Voiture("Citroen", "C5", (short) 3, "KLK 390 DD"));

		Chauffeur c2 = Application.creerCompteChauffeur("Jean", "Mineur", "897 avenue des lilas",
				"jeanjean@montaxi.fr", "ptaxi", (short) 9378943);
		c2.setPosition(69006);
		c2.setVehicule(new Voiture("BMW", "Serie 5", (short) 3, "LDD 224 OL"));

		Chauffeur c3 = Application.creerCompteChauffeur("Karim", "Belhanda", "30 route de strasbourg",
				"karimb@allotaxi.fr", "ptaxi", (short) 930903);
		c3.setPosition(69006);
		c3.setVehicule(new Helicoptere("Apache", "FX345", (short) 6));

		// Compte admin
		Application.creerCompteAdmin("admin@epsi.fr", "admin");

	} catch (Exception e) {
		e.printStackTrace();
	}
}*/

}
