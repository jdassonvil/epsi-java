package fr.hubert.app;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import fr.hubert.enums.VehiculeType;
import fr.hubert.exception.AuthentificationException;
import fr.hubert.exception.OperationNonAutoriseeException;
import fr.hubert.exception.TaxiNonTrouveException;
import fr.hubert.exception.UtilisateurDejaExistantException;
import fr.hubert.exception.UtilisateurNonTrouveException;
import fr.hubert.exception.VehiculeNonSupporteException;
import fr.hubert.interfaces.ISourceDeDonnee;
import fr.hubert.model.Admin;
import fr.hubert.model.Chauffeur;
import fr.hubert.model.Client;
import fr.hubert.model.Helicoptere;
import fr.hubert.model.Moto;
import fr.hubert.model.Utilisateur;
import fr.hubert.model.Voiture;
import fr.hubert.persistance.DatabasePersistance;

public class Actions {

	private static Map<String, Utilisateur> utilisateurs = new HashMap<String, Utilisateur>();

	//private static ISourceDeDonnee sourceDeDonne = new FilePersistance();
	private static ISourceDeDonnee sourceDeDonne = new DatabasePersistance();

	public static Client creerCompteClient(String nom, String prenom, String adresse, String email, String password)
			throws UtilisateurDejaExistantException {

		if (sourceDeDonne.trouverUtilisateur(email) != null) {
			throw new UtilisateurDejaExistantException();
		}

		return sourceDeDonne.creerCompteClient(nom, prenom, adresse, email, password);
	}

	public static Chauffeur creerCompteChauffeur(String nom, String prenom, String adresse, String email,
			String password, int license) throws UtilisateurDejaExistantException {

		if (sourceDeDonne.trouverUtilisateur(email) != null) {
			throw new UtilisateurDejaExistantException();
		}

		return sourceDeDonne.creerCompteChauffeur(nom, prenom, adresse, email, password, license);
	}

	public static Admin creerCompteAdmin(String email, String password) throws UtilisateurDejaExistantException {

		if (sourceDeDonne.trouverUtilisateur(email) != null) {
			throw new UtilisateurDejaExistantException();
		}
		
		return sourceDeDonne.creerCompteAdmin(email, password);
	}

	public static Utilisateur authentifie(String username, String password) throws AuthentificationException {
		Utilisateur u = sourceDeDonne.trouverUtilisateur(username);

		if (u == null) {
			throw new AuthentificationException();
		}

		if (!u.checkPassword(password)) {
			throw new AuthentificationException();
		}

		return u;
	}
	
	public static void ajouterVehicule(String username, VehiculeType type, int capacite, String marque,
			String modele, String immatriculation)
					throws OperationNonAutoriseeException, UtilisateurNonTrouveException, VehiculeNonSupporteException{
		Utilisateur u = sourceDeDonne.trouverUtilisateur(username);
		
		if(u == null){
			throw new UtilisateurNonTrouveException();
		}
		
		if(! (u instanceof Chauffeur)){
			throw new OperationNonAutoriseeException();
		}
		
		Chauffeur c = (Chauffeur)u;
		
		switch(type){
		case VOITURE:
			c.setVehicule(new Voiture(marque, modele, capacite, immatriculation));
			break;
		case MOTO:
			c.setVehicule(new Moto(marque, modele, immatriculation));
			break;
		case HELICO:
			c.setVehicule(new Helicoptere(marque, modele, capacite));
			break;
		default:
			throw new VehiculeNonSupporteException();
		}
			
	}

	public static List<Chauffeur> trouverTaxi(int position) throws TaxiNonTrouveException {

		List<Chauffeur> chauffeursDisponibles = new ArrayList<>();

		for (Utilisateur u : utilisateurs.values()) {
			if (u instanceof Chauffeur) {
				Chauffeur c = (Chauffeur) u;
				if (c.getPosition() == position && c.estDisponible() && c.getVehicule() != null) {
					chauffeursDisponibles.add(c);
				}
			}
		}

		if (chauffeursDisponibles.size() == 0) {
			throw new TaxiNonTrouveException();
		}

		return chauffeursDisponibles;
	}

	public static int nbUtilisateurs() {
		return utilisateurs.size();
	}

	public static int nbMoto() {
		int nbMoto = 0;
		for (Utilisateur u : utilisateurs.values()) {
			if (u instanceof Chauffeur && ((Chauffeur) u).getVehicule() instanceof Moto) {
				nbMoto++;
			}
		}

		return nbMoto;
	}

	public static int nbHelico() {
		int nbHelico = 0;
		for (Utilisateur u : utilisateurs.values()) {
			if (u instanceof Chauffeur && ((Chauffeur) u).getVehicule() instanceof Helicoptere) {
				nbHelico++;
			}
		}

		return nbHelico;
	}

	public static int nbVoiture() {
		int nbVoiture = 0;
		for (Utilisateur u : utilisateurs.values()) {
			if (u instanceof Chauffeur && ((Chauffeur) u).getVehicule() instanceof Voiture) {
				nbVoiture++;
			}
		}

		return nbVoiture;
	}

}
