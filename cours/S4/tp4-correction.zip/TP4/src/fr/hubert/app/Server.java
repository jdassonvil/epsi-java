package fr.hubert.app;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	private ServerSocket server = null;
	private static final int PORT = 5123;

	public void start() {

		try {
			server = new ServerSocket(PORT);
			this.listen();
		} catch (IOException e) {
			System.err.println(e.getMessage());
			return;
		} finally {
			// Le server n'a pas pu �tre initialis�
			// Peut �tre car le port est d�j� utilis�
			try {
				if (server != null) {
					server.close();
				}
			} catch (IOException e) {
				System.err.println(e.getMessage());
			}
		}

	}

	private void listen() {
		while (true) {

			Socket s = null;

			try {
				System.out.println("[Server] En attente d'une connexion entrante...");
				s = server.accept();
				System.out.println("[Server] Connexion entrante");
				// Chaque nouvelle requ�te entrante est g�r�e par un thread
				new Thread(new RequestHandler(s)).start();
			} catch (IOException e) {
				System.err.println("Erreur de traitement d'une requ�te: " + e.getMessage());
			}
			// Pas de finally, la socket sera ferm�e par le thread

		}

	}
}
