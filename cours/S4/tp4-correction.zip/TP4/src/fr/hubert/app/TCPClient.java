package fr.hubert.app;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ConnectException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.List;

import fr.hubert.enums.StatusCode;
import fr.hubert.enums.VehiculeType;
import fr.hubert.model.Chauffeur;
import fr.hubert.model.Stats;
import fr.hubert.model.Utilisateur;
import fr.hubert.request.AuthentificationRequest;
import fr.hubert.request.CreationDeCompteRequest;
import fr.hubert.request.CreationDeVehiculeRequest;
import fr.hubert.request.RechercheTaxiRequest;
import fr.hubert.request.StatsRequest;
import fr.hubert.response.AuthentificationResponse;
import fr.hubert.response.CreationDeCompteResponse;
import fr.hubert.response.CreationDeVehiculeResponse;
import fr.hubert.response.RechercheTaxiResponse;
import fr.hubert.response.StatsResponse;

public class TCPClient {

	// M�thode g�n�rique pour envoyer un objet vers le serveur distant
	private Object envoyer(Serializable request) throws IOException {

		Socket s = null;
		ObjectOutputStream oos = null;
		ObjectInputStream ois = null;

		try {
			s = new Socket("localhost", 5123);
			System.out.println("[TCPClient] Connexion �tablie au serveur");

			oos = new ObjectOutputStream(s.getOutputStream());
			oos.writeObject(request);

			// Envoi des donn�es � travers le r�seau
			oos.flush();
			System.out.println("[TCPClient] Requ�te envoy�e");
			ois = new ObjectInputStream(s.getInputStream());

			System.out.println("[TCPClient] R�ponse re�ue");
			return ois.readObject();

		} catch (UnknownHostException e) {
			System.err.println("Host inconnu");
			return null;
		} catch (ConnectException e) {
			System.err.println("La connexion avec le serveur distant ne peut pas �tre �tabli");
			return null;
		} catch (ClassNotFoundException e) {
			System.err.println(e.getMessage());
			return null;
		} finally {
			// Fermeture de la socket et des flux
			if (s != null) {
				s.close();
			}

			if (oos != null) {
				oos.close();
			}

			if (ois != null) {
				ois.close();
			}
		}

	}

	// M�thode permettant d'envoyer une requ�te d'authentification au serveur
	public Utilisateur authentification(String username, String password) throws IOException {

		Object response = envoyer(new AuthentificationRequest(username, password));

		if (response instanceof AuthentificationResponse) {
			AuthentificationResponse authentificationResponse = (AuthentificationResponse) response;

			if (StatusCode.OK.equals(authentificationResponse.getStatusCode())) {
				return authentificationResponse.getUtilisateur();
			} else {
				return null;
			}

		} else {
			return null;
		}
	}

	// M�thode permettant d'envoyer une requ�te de recherche de taxi
	public List<Chauffeur> rechercheTaxi(int codePostal) throws IOException {

		Object response = envoyer(new RechercheTaxiRequest(codePostal));

		if (response instanceof RechercheTaxiResponse) {
			return ((RechercheTaxiResponse) response).getChauffeurs();

		} else {
			return null;
		}
	}

	// M�thode permettant d'envoyer une requ�te de cr�ation de compte client
	public boolean creationDeCompteClient(String nom, String prenom, String adresse, String email, String password)
			throws IOException {

		Object response = envoyer(new CreationDeCompteRequest(nom, prenom, adresse, email, password));

		if (response instanceof CreationDeCompteResponse) {
			return StatusCode.OK.equals(((CreationDeCompteResponse) response).getStatusCode());

		} else {
			return false;
		}
	}

	// M�thode permettant d'envoyer une requ�te de cr�ation de compte chauffeur
	public boolean creationDeCompteChauffeur(String nom, String prenom, String adresse, String email, String password,
			int license) throws IOException {

		Object response = envoyer(new CreationDeCompteRequest(nom, prenom, adresse, email, password, license));

		if (response instanceof CreationDeCompteRequest) {
			return StatusCode.OK.equals(((CreationDeCompteRequest) response));

		} else {
			return false;
		}
	}

	// M�thode permettant d'envoyer une requ�te de calcul de stats
	public Stats calculerStats() throws IOException {
		Object response = envoyer(new StatsRequest());

		if (response instanceof StatsResponse) {
			return ((StatsResponse) response).getStats();

		} else {
			return null;
		}
	}

	// M�thode permettant d'envoyer une requ�te de cr�ation de vehicules
	public boolean creationDeVehicule(VehiculeType type, String marque, String modele, String immatriculation,
			int capacite, String username) throws IOException {
		Object response = envoyer(
				new CreationDeVehiculeRequest(type, marque, modele, immatriculation, capacite, username));
		if (response instanceof CreationDeVehiculeResponse) {
			return StatusCode.OK.equals(((CreationDeVehiculeResponse) response).getStatusCode());

		} else {
			return false;
		}

	}

}
