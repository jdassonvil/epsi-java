package fr.hubert.response;

import fr.hubert.enums.StatusCode;
import fr.hubert.model.Stats;

public class StatsResponse extends GenericResponse{

	// Utile uniquement pour la s�rialization
	private static final long serialVersionUID = -1172862566665818211L;
	
	private Stats stats;

	public StatsResponse(StatusCode statusCode, String message, Stats stats) {
		super(statusCode, message);
		this.stats = stats;
	}
	
	public Stats getStats() {
		return stats;
	}
	
}
