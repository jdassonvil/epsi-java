package fr.hubert.response;

import java.util.ArrayList;
import java.util.List;

import fr.hubert.enums.StatusCode;
import fr.hubert.model.Chauffeur;

public class RechercheTaxiResponse extends GenericResponse {

	// Utile uniquement pour la s�rialization

	private static final long serialVersionUID = 842203067512953576L;
	
	private List<Chauffeur> chauffeurs;
	
	// Construit une r�ponse avec une liste de chauffeurs vide
	public RechercheTaxiResponse(StatusCode statusCode, String message) {
		super(statusCode, message);
		this.chauffeurs = new ArrayList<Chauffeur>();
	}

	
	public RechercheTaxiResponse(StatusCode statusCode, String message, List<Chauffeur> chauffeurs) {
		super(statusCode, message);
		this.chauffeurs = chauffeurs;
	}

	public List<Chauffeur> getChauffeurs() {
		return chauffeurs;
	}
	
}