package fr.hubert.exception;

public class TaxiNonTrouveException extends Exception {

	// Utile uniquement pour la s�rialization
	private static final long serialVersionUID = -5466234124784957534L;

}
