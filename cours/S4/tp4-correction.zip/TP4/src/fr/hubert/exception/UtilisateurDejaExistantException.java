package fr.hubert.exception;

public class UtilisateurDejaExistantException extends Exception {

	// Utile uniquement pour la s�rialization
	private static final long serialVersionUID = -6792192025830904588L;

}
