package fr.hubert.exception;

public class AucuneEvaluationException extends Exception {

	// Utile uniquement pour la s�rialization
	private static final long serialVersionUID = -679298321557423912L;

}
