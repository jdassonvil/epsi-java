package fr.hubert.interfaces;

import java.util.List;

import fr.hubert.exception.UtilisateurDejaExistantException;
import fr.hubert.model.Admin;
import fr.hubert.model.Chauffeur;
import fr.hubert.model.Client;
import fr.hubert.model.Utilisateur;

public interface ISourceDeDonnee {
	
	public List<Utilisateur> chargerUtilisateurs();
	
	public Utilisateur trouverUtilisateur(String username);

	public Client creerCompteClient(String nom, String prenom, String adresse, String email, String password);

	public Chauffeur creerCompteChauffeur(String nom, String prenom, String adresse, String email, String password, int license);

	public Admin creerCompteAdmin(String email, String password) throws UtilisateurDejaExistantException;

}
