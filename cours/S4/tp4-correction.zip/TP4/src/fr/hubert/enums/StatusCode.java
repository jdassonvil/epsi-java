package fr.hubert.enums;

public enum StatusCode {

	OK(0), BAD_REQUEST(10), BAD_CREDENTIALS(11), ALREADY_EXIST(12), BAD_IDENTITY(13), KO_UNKNOWN(99);

	private int code;

	private StatusCode(int code) {
		this.code = code;
	}

	public int getValue() {
		return this.code;
	}
	
}
