package fr.hubert.enums;

public enum UserType {

	ADMIN(0), CLIENT(2), CHAUFFEUR(1);
	
	private int intValue;
	
	private UserType(int intValue){
		this.intValue = intValue;
	}
	
	public static UserType fromInteger(int intValue){
		
		switch(intValue){
		case 0:
			return ADMIN;
		case 1:
			return CHAUFFEUR;
		case 2:
			return CLIENT;
			default:
				throw new IllegalArgumentException();
		}
	}
	
	public int getIntValue() {
		return intValue;
	}
}
