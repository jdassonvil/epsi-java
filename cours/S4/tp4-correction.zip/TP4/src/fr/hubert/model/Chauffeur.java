package fr.hubert.model;

import java.util.LinkedList;
import java.util.List;

import fr.hubert.exception.AucuneEvaluationException;
import fr.hubert.interfaces.IEvaluable;

public class Chauffeur extends Utilisateur implements IEvaluable {

	// Utile uniquement pour la s�rialization
	private static final long serialVersionUID = -1335033066016615955L;

	private String nom;
	private String prenom;
	private String adresse;
	private String email;
	private int license;
	
	private boolean disponible;
	private int position;
	private Vehicule vehicule;
	
	private List<Evaluation> evaluations = new LinkedList<Evaluation>();

	private static int compteur = 0;

	public Chauffeur(String nom, String prenom, String adresse, String email, String password,
			int license) {
		super(email, password);
		
		this.nom = nom;
		this.prenom = prenom;
		this.adresse = adresse;
		this.email = email;
		this.license = license;
		this.disponible = true;
		this.position = -1;
		
		compteur++;
	}

	public static int getNbChauffeur() {
		return compteur;
	}
	
	public int getPosition() {
		return position;
	}
	
	public void setPosition(int position) {
		this.position = position;
	}

	public String getNom() {
		return nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public String getAdresse() {
		return adresse;
	}

	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getLicense() {
		return license;
	}

	public void setLicense(int license) {
		this.license = license;
	}

	public static void afficherString() {
		System.out.println("Hello");
	}
	
	public boolean estDisponible(){
		return disponible;
	}
	
	public Vehicule getVehicule() {
		return vehicule;
	}
	
	public void setVehicule(Vehicule vehicule) {
		this.vehicule = vehicule;
	}

	@Override
	public String toString() {
		return "Chauffeur [nom=" + nom + ", prenom=" + prenom + ", adresse="
				+ adresse + ", email=" + email + ", license=" + license + "]";
	}

	@Override
	public void setEvaluation(Evaluation eval) {
		if(eval != null){
			this.evaluations.add(eval);
		}
	}

	@Override
	public int getEvaluationMoyenne() throws AucuneEvaluationException {
		
		if(evaluations.size() == 0){
			throw new AucuneEvaluationException();
		}
		
		int somme = 0;
		for(Evaluation eval: evaluations){
			somme += eval.getNote();
		}
		
		return somme/evaluations.size();
	}

	@Override
	public List<Evaluation> getEvaluations() {
		return evaluations;
	}

}
