package fr.hubert.model;

import fr.hubert.enums.VehiculeType;

public class Helicoptere extends Vehicule{
	
	// Utile uniquement pour la s�rialization
	private static final long serialVersionUID = 9051413812185702542L;

	// Tarif en � au km
	private static float TARIF = 10f;
	
	public Helicoptere(String marque, String modele, int capacite) {
		super(VehiculeType.HELICO, marque, modele, capacite);
	}
	
	@Override
	public float getTarif() {
		return TARIF;
	}

	@Override
	public String getDescription() {
		return this.getMarque() + " " + this.getModele() + " pour " + this.capacite + " personne(s)";
	}
}
