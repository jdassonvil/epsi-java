package fr.hubert.model;

import fr.hubert.enums.VehiculeType;

public class Moto extends Vehicule {
	
	// Utile uniquement pour la s�rialization
	private static final long serialVersionUID = 3442210747584523844L;
	
	private static int CAPACITE_MOTO = 1;
	private String immatriculation;
	
	// Tarif en � au km
	private static float TARIF = 3f;
	
	public Moto(String marque, String modele, String immatriculation) {
		super(VehiculeType.MOTO, marque, modele, CAPACITE_MOTO);
		this.immatriculation = immatriculation;
	}

	@Override
	public float getTarif() {
		return TARIF;
	}
	
	public String getImmatriculation() {
		return immatriculation;
	}
	
	@Override
	public String getDescription() {
		return this.getMarque() + " " + this.getModele() + " pour " + this.capacite + " personne(s)";
	}
}
