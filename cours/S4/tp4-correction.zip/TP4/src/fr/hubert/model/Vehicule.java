package fr.hubert.model;

import java.io.Serializable;

import fr.hubert.enums.VehiculeType;

public abstract class Vehicule implements Serializable{
	
	// Utile uniquement pour la s�rialization
	private static final long serialVersionUID = 6946398169410485702L;
	
	protected String marque;
	protected String modele;
	protected int capacite;
	
	protected VehiculeType type;
	
	public Vehicule(VehiculeType type, String marque, String modele, int capacite) {
		this.type = type;
		this.marque = marque;
		this.modele = modele;
		this.capacite = capacite;
	}
	
	public String getMarque() {
		return marque;
	}
	public void setMarque(String marque) {
		this.marque = marque;
	}
	public String getModele() {
		return modele;
	}
	public void setModele(String modele) {
		this.modele = modele;
	}
	public int getCapacite() {
		return capacite;
	}
	public void setCapacite(int capacite) {
		this.capacite = capacite;
	}
	
	public String getNomVehicule() {
		return type.getValue();
	}
	
	public abstract float getTarif();
	
	public abstract String getDescription();

}
