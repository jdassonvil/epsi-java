
package fr.hubert.model;

import java.io.Serializable;

public abstract class Utilisateur implements Serializable{
	
	// Utile uniquement pour la s�rialization
	private static final long serialVersionUID = 8939719475093247031L;
	
	protected String username;
	private String password;
	
	protected Utilisateur(String username, String password){
		this.username = username;
		this.password = password;
	}
	
	public String getUsername() {
		return username;
	}
	
	public boolean checkPassword(String password){
		return  this.password.equals(password);
	}

}
