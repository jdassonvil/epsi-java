package fr.hubert.model;

public class Admin extends Utilisateur {

	// Utile uniquement pour la s�rialization
	private static final long serialVersionUID = -9184139526016341896L;

	public Admin(String username, String password){
		super(username, password);
	}

	@Override
	public String toString() {
		return "Admin [username=" + username + "]";
	}
	
}
